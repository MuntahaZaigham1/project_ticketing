module.exports.nothing6 = function(req, res) {
    res.render("landing.html", {
    });
};